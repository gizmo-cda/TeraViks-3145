
from .magicrobot import MagicRobot
